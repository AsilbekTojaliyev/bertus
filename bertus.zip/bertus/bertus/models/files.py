from sqlalchemy.orm import relationship, backref
from db import Base
from sqlalchemy import Column, Integer, String, and_, Text

from models.anketa import Worker
from models.user import User


class Files(Base):
    __tablename__ = "files"
    id = Column(Integer, primary_key=True, autoincrement=True)
    file = Column(Text)
    source = Column(String(255))
    source_id = Column(Integer)

    worker = relationship("Worker", foreign_keys=[source_id],
                          primaryjoin=lambda: and_(Worker.id == Files.source_id, Files.source == "worker"),
                          backref=backref("files"))
    user = relationship("User", foreign_keys=[source_id],
                        primaryjoin=lambda: and_(User.id == Files.source_id, Files.source == "user"),
                        backref=backref("files"))

from sqlalchemy import Column, String, Integer, Date, Boolean
from db import Base


class Worker(Base):
    __tablename__ = "anketa"
    id = Column(Integer, primary_key=True, autoincrement=True)
    a1 = Column(Date)
    a2 = Column(String(255))
    a3 = Column(Integer)
    a4 = Column(Integer)
    a5 = Column(String(255))
    a6 = Column(String(255))
    a7 = Column(String(255))
    a8 = Column(Boolean)
    a9 = Column(Boolean)
    a10 = Column(String(255))
    a11 = Column(Boolean)
    a12 = Column(String(255))
    a13 = Column(String(255))
    a14 = Column(String(255))
    a15 = Column(String(255))
    a16 = Column(String(255))
    a17 = Column(String(255))
    a18 = Column(String(255))
    a19 = Column(String(255))
    a20 = Column(String(255))
    a21 = Column(String(255))
    a22 = Column(String(255))
    a23 = Column(String(255))
    a24 = Column(String(255))
    a25 = Column(String(255))
    a26 = Column(String(255))
    a27 = Column(String(255))
    a28 = Column(String(255))
    a29 = Column(Integer)
    a30 = Column(String(255))





from datetime import datetime

from pydantic import BaseModel, Field
from db import SessionLocal

db = SessionLocal()


class CreateWorker(BaseModel):
    a1: datetime
    a2: str
    a3: int = Field(..., gt=0)
    a4: int = Field(..., gt=0)
    a5: str
    a6: str
    a7: str
    a8: bool
    a9: bool
    a10: str
    a11: bool
    a12: str
    a13: str
    a14: str
    a15: str
    a16: str
    a17: str
    a18: str
    a19: str
    a20: str
    a21: str
    a22: str
    a23: str
    a24: str
    a25: str
    a26: str
    a27: str
    a28: str
    a29: int = Field(..., gt=0)
    a30: str



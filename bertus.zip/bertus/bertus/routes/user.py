from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from functions.user import get_admin, create_admin, delete_admin, get_own
from routes.login import get_current_active_user
from schemas.user import CreateUser
from db import database

admin_router = APIRouter(
    prefix="/Admin",
    tags=["Admin operation"]
)


@admin_router.get('/get_all_admin')
def get(db: Session = Depends(database),
        current_user: CreateUser = Depends(get_current_active_user)):
    return get_admin(db)


@admin_router.get('/get_own')
def get_my(db: Session = Depends(database),
            current_user: CreateUser = Depends(get_current_active_user)):
    return get_own(db, current_user)


@admin_router.post('/create_admin')
def create(form: CreateUser, db: Session = Depends(database),
           current_user: CreateUser = Depends(get_current_active_user)):
    create_admin(form, db)
    raise HTTPException(status_code=200, detail="Amaliyot muvaffaqiyatli amalga oshirildi")


@admin_router.delete("/delete")
def delete(db: Session = Depends(database),
           current_user: CreateUser = Depends(get_current_active_user)):
    delete_admin(db, current_user)
    raise HTTPException(status_code=200, detail="Amaliyot muvaffaqiyatli amalga oshirildi")

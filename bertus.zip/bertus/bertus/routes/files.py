from fastapi import Depends, APIRouter, HTTPException
from sqlalchemy.orm import Session
from functions.files import create_file, update_file, delete_file
from schemas.files import CreateFile
from db import database


files_router: APIRouter = APIRouter(
    prefix="/files",
    tags=["Files operation"]
)


@files_router.post("/create")
async def create(
        form: CreateFile = Depends(CreateFile),
        db: Session = Depends(database)):
    create_file(form.new_files, form.source, form.source_id, db)
    raise HTTPException(200, "Amaliyot muvaffaqiyatli amalga oshirildi !!!")


@files_router.put("/update")
async def update(
        form: CreateFile = Depends(CreateFile),
        db: Session = Depends(database)):
    update_file(form.new_files, form.source, form.source_id, db)
    raise HTTPException(200, "Amaliyot muvaffaqiyatli amalga oshirildi !!!")


@files_router.delete("/delete")
def delete(ident: int, db: Session = Depends(database)):
    delete_file(ident, db)
    raise HTTPException(200, "Amaliyot muvaffaqiyatli amalga oshirildi !!!")

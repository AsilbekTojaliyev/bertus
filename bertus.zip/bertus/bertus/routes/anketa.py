from typing import List

from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from functions.anketa import get_worker, create_worker, delete_worker
from routes.login import get_current_active_user
from schemas.user import CreateUser
from schemas.anketa import CreateWorker
from db import database


worker_router = APIRouter(
    prefix="/Worker",
    tags=["Worker operation"]
)


@worker_router.get('/get_worker')
def get(db: Session = Depends(database),
        current_user: CreateUser = Depends(get_current_active_user)):
    return get_worker(db)


@worker_router.post('/create_worker')
def create(form: CreateWorker, db: Session = Depends(database)):
    create_worker(form, db)
    raise HTTPException(status_code=200, detail="Amaliyot muvaffaqiyatli amalga oshirildi")


@worker_router.delete('/delete_worker')
def delete(idents: List[int],
           db: Session = Depends(database),
           current_user: CreateUser = Depends(get_current_active_user)):
    delete_worker(idents, db)
    raise HTTPException(200, "Succsess!!!")



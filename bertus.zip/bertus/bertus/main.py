from fastapi import FastAPI
from routes.login import login_router
from routes.user import admin_router
from routes.anketa import worker_router
from routes.files import files_router

app = FastAPI(docs_url="/")

app.include_router(worker_router)
app.include_router(files_router)
app.include_router(admin_router)
app.include_router(login_router)










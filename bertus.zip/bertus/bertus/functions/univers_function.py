from fastapi import HTTPException


def newItemDb(db, a):
    db.add(a)
    db.commit()
    db.refresh(a)


def get_in_db(db, model, ident=int):
    m = db.query(model).filter(model.id == ident).first()
    if m is None:
        raise HTTPException(400, " Xatolik !!! ")
    return m
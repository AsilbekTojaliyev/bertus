from functions.univers_function import newItemDb
from models.anketa import Worker
from fastapi import HTTPException
from sqlalchemy.orm import joinedload


def get_worker(db):
    return db.query(Worker).options(joinedload(Worker.files)).all()


def create_worker(form, db):
    new_item_db = Worker(
        a1=form.a1,
        a2=form.a2,
        a3=form.a3,
        a4=form.a4,
        a5=form.a5,
        a6=form.a6,
        a7=form.a7,
        a8=form.a8,
        a9=form.a9,
        a10=form.a10,
        a11=form.a11,
        a12=form.a12,
        a13=form.a13,
        a14=form.a14,
        a15=form.a15,
        a16=form.a16,
        a17=form.a17,
        a18=form.a18,
        a19=form.a19,
        a20=form.a20,
        a21=form.a21,
        a22=form.a22,
        a23=form.a23,
        a24=form.a24,
        a25=form.a25,
        a26=form.a26,
        a27=form.a27,
        a28=form.a28,
        a29=form.a29,
        a30=form.a30
    )
    newItemDb(db, new_item_db)


def delete_worker(idents, db):
    for ident in idents:
        delete_wk = db.query(Worker).filter(Worker.id == ident).first()

        if delete_wk is None:
            raise HTTPException(400, "Bunday id li ishchi yoq !!!")

        db.query(Worker).filter(Worker.id == ident).delete()

    db.commit()

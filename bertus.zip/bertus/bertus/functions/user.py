from routes.login import get_password_hash
from functions.univers_function import newItemDb
from models.user import User
from sqlalchemy.orm import joinedload


def get_admin(db):
    return db.query(User).options(joinedload(User.files)).all()


def get_own(db, user):
    return db.query(User).options(joinedload(User.files)).filter(User.id == user.id).all()


def create_admin(form, db):
    new_item_db = User(
        name=form.name,
        username=form.username,
        role="admin",
        password=get_password_hash(form.password))
    newItemDb(db, new_item_db)


def delete_admin(db, user):
    db.query(User).filter(User.id == user.id).delete()
    db.commit()









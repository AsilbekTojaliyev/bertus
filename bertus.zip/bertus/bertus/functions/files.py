import os
from fastapi import HTTPException
from models.files import Files
from models.anketa import Worker
from functions.univers_function import get_in_db
from models.user import User


def create_file(new_files, source, source_id, db):
    if (source == "worker" and db.query(Worker).filter(Worker.id == source_id).first() is None) or \
            (source == "user" and db.query(User).filter(User.id == source_id).first() is None):
        raise HTTPException(400, "File biriktirilgan obyekt topilmadi !!!")

    uploaded_file_object = []

    for new_file in new_files:
        ext = os.path.splitext(new_file.filename)[-1].lower()
        if ext not in [".jpg", ".png", ".gif", "jpeg"]:
            raise HTTPException(400, "Yuklanayotgan fayl formati noto'g'ri !!!")
        file_location = f"files/{new_file.filename}"
        with open(file_location, "wb+") as file_object:
            file_object.write(new_file.file.read())

        new_item_db = Files(
            file=new_file.filename,
            source=source,
            source_id=source_id
        )
        uploaded_file_object.append(new_item_db)

    db.add_all(uploaded_file_object)
    db.commit()


def delete_file(ident, db):
    get_in_db(db, Files, ident)
    db.query(Files).filter(Files.id == ident).delete()
    db.commit()


def update_file(new_files, source, source_id, db):
    items = db.query(Files).filter(Files.source == source,
                                   Files.source_id == source_id).all()
    for item in items:
        delete_file(item.id, db)
    create_file(new_files, source, source_id, db)
